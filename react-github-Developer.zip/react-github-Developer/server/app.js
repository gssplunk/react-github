var express = require('express');
var app = express();
var fs = require("fs");
const cors = require('cors');
const bodyParser = require('body-parser');
const http = require("http");
const socketIo = require("socket.io");

app.use(express.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(cors());

const IndexRouter = express.Router();
const github = require('./Route/github');


IndexRouter.use('/git', github);

const _server = http.createServer(app);

const io = socketIo(_server);

let _socket;

let interval;

io.on("connection", (socket) => {
   console.log("New client connected");
   _socket = socket;
   if (interval) {
     clearInterval(interval);
   }
   socket.on("disconnect", () => {
     console.log("Client disconnected");
     clearInterval(interval);
   });
 });
 
 exports.getApiAndEmit = socket => {
   const response = new Date();
   // Emitting a new message. Will be consumed by the client
   _socket.emit("PullRequestState", socket);
 };

app.get('/test', function (req, res) {
   res.status(200).send({
      success: true,
      message: "Welcome to Github React APP"
   });
});

app.use('/api', IndexRouter);

// var server = app.listen(3002, function () {
//    var host = 'localhost'
//    var port = server.address().port
//    console.log("Example app listening at http://%s:%s/api", host, port)
// })

_server.listen(3002, () => console.log(`Listening on port 3002`));
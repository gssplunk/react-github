const express = require('express');
const router = express.Router();
const {
    getPullRequestList, getSingleFileData, createPullRequest, commitApi, getFileContent, socketApi
} = require('../Controller/github')


router.post('/commitApi', commitApi);
router.post('/createPullRequest', createPullRequest);
router.get('/getPullRequestList', getPullRequestList);
router.get('/getSingleFileData/:path', getSingleFileData);
router.post('/getFileContent', getFileContent);
router.post('/socketApi', socketApi);

module.exports = router;

module.exports = {
    username: 'Enter github username', // Enter github username
    access_token: 'Enter github user token', // Enter github user token
    Repo_Name: 'Enter Github repository name', // Enter Github repository name

    pull_req_compare_branch: "develop", // Enter compare branch for pull request
    pull_req_base_branch: "master", // Enter base branch for pull request
}
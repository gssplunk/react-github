const axios = require('axios');
const socketIO = require("socket.io");
const express = require("express");
const http = require("http");
const _app = require("../app");
const app = express();
// our server instance
//const server = http.createServer(app);
// This creates our socket using the instance of the server
//const io = socketIO(server);

const {
    username
    , access_token
    , Repo_Name

    // , pull_req_title
    // , pull_req_body
    , pull_req_compare_branch
    , pull_req_base_branch

    // , fileName
    // , fileContent
    // , commit_msg
} = require('../constants');
const { json } = require('body-parser');


const getCircularReplacer = () => {
    const seen = new WeakSet();
    return (key, value) => {
        if (typeof value === "object" && value !== null) {
            if (seen.has(value)) {
                return;
            }
            seen.add(value);
        }
        return value;
    };
};

// This function for create new pull request
const createPullRequest = async (req, res, next) => {
    const {
        pull_req_title,
        pull_req_body
        // pull_req_compare_branch,
        // pull_req_base_branch
    } = req.body;

    try {
        let PR_List = await get_Pull_Request_List_api();

        //Check condition for already pull request generated or not
        if (PR_List.length > 0) {
            res.status(200).json({ success: 'false', data: {} });
        } else {
            let finalResponse;
            await axios({
                method: 'POST',
                url: `https://api.github.com/repos/${username}/${Repo_Name}/pulls`,
                headers: {
                    'Authorization': `token ${access_token}`
                },
                data: {
                    "title": pull_req_title,
                    "body": pull_req_body,
                    "head": `${username}:${pull_req_compare_branch}`,
                    "base": pull_req_base_branch
                }
            })
                .then(function (response) {
                    finalResponse = JSON.parse(JSON.stringify(response, getCircularReplacer()));
                })
                .catch(function (error) {
                    finalResponse = JSON.parse(JSON.stringify(error, getCircularReplacer()));
                });

            res.status(200).json({ success: 'true', data: finalResponse.data });
        }
    } catch (err) {
        next(err)
    }
}

// commitApi function use save or commit the latest changes to github
const commitApi = async (req, res, next) => {
    const { fileName, fileContent, commit_msg } = req.body;

    try {
        let getDevelopBranchKeyResponse;

        await axios({
            method: 'GET',
            url: `https://api.github.com/repos/${username}/${Repo_Name}/git/refs/heads/${pull_req_compare_branch}`,
            headers: {
                'Authorization': `token ${access_token}`
            },
        }).then(function (response) {
            getDevelopBranchKeyResponse = JSON.parse(JSON.stringify(response, getCircularReplacer()));
        }).catch(function (error) {
            getDevelopBranchKeyResponse = error;
        });

        let getDevelopBranchFileKeyResponse;
        await axios({
            method: 'GET',
            url: `https://api.github.com/repos/${username}/${Repo_Name}/git/commits/` + getDevelopBranchKeyResponse.data.object.sha,
            headers: {
                'Authorization': `token ${access_token}`
            },
        }).then(function (response) {
            getDevelopBranchFileKeyResponse = JSON.parse(JSON.stringify(response, getCircularReplacer()));
        }).catch(function (error) {
            getDevelopBranchFileKeyResponse = error;
        });

        let fileUpdateResponse;

        await axios({
            method: 'POST',
            url: `https://api.github.com/repos/${username}/${Repo_Name}/git/trees`,
            headers: {
                'Authorization': `token ${access_token}`
            },
            data: {
                "base_tree": getDevelopBranchFileKeyResponse.data.tree.sha,
                "tree": [
                    {
                        "path": fileName,
                        "mode": "100644",
                        "type": "blob",
                        "content": fileContent
                    }
                ]
            }
        }).then(function (response) {
            fileUpdateResponse = JSON.parse(JSON.stringify(response, getCircularReplacer()));
        }).catch(function (error) {
            fileUpdateResponse = JSON.parse(JSON.stringify(error, getCircularReplacer()));
        });

        let fileCommitResponse;

        await axios({
            method: 'POST',
            url: `https://api.github.com/repos/${username}/${Repo_Name}/git/commits`,
            headers: {
                'Authorization': `token ${access_token}`
            },
            data: {
                "parents": [getDevelopBranchKeyResponse.data.object.sha],
                "tree": fileUpdateResponse.data.sha,
                "message": commit_msg
            }
        }).then(function (response) {
            fileCommitResponse = JSON.parse(JSON.stringify(response, getCircularReplacer()));
        }).catch(function (error) {
            fileCommitResponse = JSON.parse(JSON.stringify(error, getCircularReplacer()));
        });

        let finalCommitResponse;

        await axios({
            method: 'POST',
            url: `https://api.github.com/repos/${username}/${Repo_Name}/git/refs/heads/${pull_req_compare_branch}`,
            headers: {
                'Authorization': `token ${access_token}`
            },
            data: {
                "sha": fileCommitResponse.data.sha
            }
        })
            .then(function (response) {
                finalCommitResponse = JSON.parse(JSON.stringify(response, getCircularReplacer()));
            })
            .catch(function (error) {
                finalCommitResponse = JSON.parse(JSON.stringify(error, getCircularReplacer()));
            });

        res.status(200).json({ success: 'true', data: finalCommitResponse.data });

    } catch (err) {
        next(err)
    }
}
// get_Pull_Request_List_api function use List the pull request
const get_Pull_Request_List_api = async (req, res, next) => {
    try {
        let finalResponse;
        await axios({
            method: 'GET',
            url: `https://api.github.com/repos/${username}/${Repo_Name}/pulls?state=Open`,
            headers: {
                'Authorization': `token ${access_token}`
            },
        }).then(function (response) {
            finalResponse = JSON.parse(JSON.stringify(response, getCircularReplacer()));
        }).catch(function (error) {
            finalResponse = error;
        });

        return (finalResponse.data)
    } catch (err) {
        next(err)
    }
}

const getPullRequestList = async (req, res, next) => {
    try {
        let PR_List = await get_Pull_Request_List_api();
        res.status(200).json({ success: 'true', data: PR_List });
    } catch (err) {
        next(err)
    }
}
//getSingleFileData using for get particular file content
const getSingleFileData = async (req, res, next) => {
    try {
        let finalResponse;
        await axios({
            method: 'GET',
            url: `https://api.github.com/repos/${username}/${Repo_Name}/contents/` + req.params.path,
            headers: {
                'Accept': 'application/vnd.github.v3.raw',
                'Authorization': `token ${access_token}`,
                "Content-Type": "application/vnd.github.v3.raw; charset=utf-8",
                "X-GitHub-Media-Type": "github.v3; param=raw"
            },
        }).then(function (response) {
            if (typeof response.data === "string") {
                finalResponse = response.data;
            } else {
                finalResponse = JSON.stringify(response.data, null, ' ');
            }
            console.log("final: ", finalResponse)
        }).catch(function (error) {
            finalResponse = error;
        });


        res.status(200).json({ success: 'true', data: finalResponse });
    } catch (err) {
        next(err)
    }
}

const getFileContent = async (req, res, next) => {
    console.log("req.body.url:: ", req.body.url);
    try {
        let finalResponse;
        await axios({
            method: 'GET',
            url: req.body.url,
            headers: {
                'Authorization': `token ${access_token}`,
                "Accept": "application/vnd.github.v3.raw",
                //"Content-Type": "application/vnd.github.v3.raw; charset=utf-8"
                "X-GitHub-Media-Type": "github.v3; param=raw"
            },
        }).then(function (response) {
            //finalResponse = JSON.parse(JSON.stringify(response, getCircularReplacer()));
            console.log("response::: ", response)
            finalResponse = response.data;
            //console.log("res::: ", JSON.stringify(finalResponse))
        }).catch(function (error) {
            console.log("err:: ", error);
            finalResponse = error;
        });
        //let _data = JSON.stringify(finalResponse.data, undefined, 2);
        //_data = JSON.parse(_data)
        console.log("finalResponse::: ", finalResponse)
        res.status(200).json({ success: 'true', data: finalResponse });
    } catch (err) {
        next(err)
    }
}

const socketApi = async (req, res, next) => {
    try {
        let response = { data: true }
        await _app.getApiAndEmit(req.body);

        res.status(200).json({ success: 'true', data: { data: true } });
    }
    catch (err) {
        next(err)
    }
}

module.exports = {
    getPullRequestList, getSingleFileData, createPullRequest, commitApi, getFileContent, socketApi
}
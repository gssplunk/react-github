import { GET_SUCCESS_PULL_REQUEST } from '../Actions/Actions';

export const HomeActions = {
    loadPullRequests: (dispatch, data) => {
        dispatch({ type: GET_SUCCESS_PULL_REQUEST, payload: data });
    }
};

const initialstate = {
    pullRequests: [],
}


let HomeReducer = (state = initialstate, action) => {
    const { type, payload } = action;

    switch (type) {
        case GET_SUCCESS_PULL_REQUEST:
            return {
                ...state,
                pullRequests: payload.data || []
            }

        default:
            return { ...state };

    }
}
export default HomeReducer;
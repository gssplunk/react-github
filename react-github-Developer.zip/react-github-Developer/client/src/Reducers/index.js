import { combineReducers } from 'redux';
import HomeReducer from './HomeReducer';

let RootReducer = combineReducers({
    homeReducer: HomeReducer
});

export default RootReducer;
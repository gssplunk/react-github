import React, { Component, useState, useEffect } from 'react';
import socketIOClient from "socket.io-client";
var socket;
const ENDPOINT = "http://192.168.43.230:3002/";

export function HomeComponent(props) {
    const initialState = {
        pullRequestList: [],
        commitMessage: '',
        editSection: props.file_info.content,
        file_name: props.file_info.file_name
    };

    const defaultToastState = {
        message: 'Test',
        isVisible: false,
        title: 'Alert',
        type: 'info'
    };

    const [formData, setFormData] = useState(initialState);

    const [toast, setToast] = useState(defaultToastState);

    const [response, setResponse] = useState({});


    useEffect(() => {
        if (props.git.pullRequests && props.git.pullRequests.length > 0) {
            setFormData({ ...formData, pullRequestList: props.git.pullRequests })
        }else{
            setFormData({ ...formData, pullRequestList: [] })
        }
        const socket = socketIOClient(ENDPOINT);
        socket.on("PullRequestState", data => {
            if(data && data.action == "closed" ){
                upDateNewStatus();
                //setResponse(data);
            }
        });
    }, [props]);

    const upDateNewStatus = async () =>{
        console.log("reload_PR_data:::  ");
        await props.reload_PR_data();
    }

    useEffect(() => {
        if (props.file_info.content) {
            setFormData({ ...formData, editSection: props.file_info.content })
        }
    }, [props.file_info.content])


    /**
     * Close the alert after 3 seconds
     */

    const displayToast = (title, message, type) => {
        setToast({ ...toast, isVisible: true, message, title, type });

        setTimeout(() => {
            setToast(defaultToastState)
        }, 3000);
    }

    /**
     * Committe the code to github respository
     */
    const commite_code = async () => {
        console.log('Update the code to server');
        setFormData({ ...formData, commitMessage: '' });
        let response = await props.code_commit({ ...formData });
        if (response) {
            let PR_response = await props.new_pull_request();
            displayToast('', 'Code has saved successsfully.', 'success');
            // if (PR_response.success === 'true') {
            //     displayToast('Pull Request Status', 'New Pull Requets has created successfully.', 'success');
            // }
            // else {
            //     displayToast('!Info', 'There is problem to create a new pull request.', 'warning');
            // }
        } else {
            displayToast('Commit Status', 'Code saved failed.', 'danger');
        }
    };


    /**
     * Create new pull request
     */
    const create_new_pull_request = async () => {
        console.log('Create pull request');
        let response = await props.new_pull_request();

        console.log('Create pull request', response);
        if (response.success === 'true') {
            displayToast('Pull Request Status', 'New Pull Requets has created successfully.', 'success');
        } else {
            displayToast('!Info', 'There is problem to create a new pull request.', 'warning');
        }
    };

    const navigate_to_request_page = () => {
        if (formData.pullRequestList) {
            let url = formData.pullRequestList[0]._links.html.href;
            // url += '/pulls';
            // url = url.replace('{/number}', req.size);
            console.log('url', url)
            var win = window.open(url, '_blank');
            win.focus();
        }
    };

    return (
        <div className="row">
            {
                toast.isVisible &&
                <div className="col-md-12">
                    <div className="card">
                        <div className="card-body">
                            <div className={`alert alert-${toast.type != '' ? toast.type : 'info'}`} role="alert">
                                <h4 className="alert-heading">{toast.title}</h4>
                                <p>{toast.message}</p>
                            </div>
                        </div>
                    </div>
                </div>
            }
            <div className="col-md-12 mb-5">
                <div className="card mt-5 main-container">
                    <div className='card-body'>
                        <div className="editor">
                            <div className="cus-label">Editor Section - <span className="file-name">{formData.file_name}</span> </div>
                            <textarea
                                className="form-control mt-2"
                                cols={95}
                                rows={13}
                                value={formData.editSection}
                                onChange={(e) => setFormData({ ...formData, editSection: e.target.value })}>
                            </textarea>
                        </div>

                        <div className="Comments setion mt-4">
                            <div className="cus-label">
                                Comments
                            </div>
                            <input
                                name="comment"
                                onChange={(e) => setFormData({ ...formData, commitMessage: e.target.value })}
                                className="commit-box form-control mt-2"
                                value={formData.commitMessage} />
                        </div>
                        <div className="btn-block">
                            <input
                                type="button"
                                className="btn btn-primary"
                                value="Save"
                                disabled={formData.commitMessage === ''}
                                onClick={commite_code}
                            />

                            <input
                                type="button"
                                className="btn btn-primary Approve-btn"
                                value="Approve Change"
                                disabled={(formData.pullRequestList.length === 0)}
                                onClick={(e) => navigate_to_request_page()}
                            />
                        </div>

                    </div>
                </div>
            </div>

            {/* <div className="col-md-6 mb-5 mt-5">
                <div className="card">
                    <div className="card-body">
                        <div className="Pull-requests">
                            <div className="pl-item">Pull Requests
                            <button
                                    onClick={create_new_pull_request}
                                    className={`btn btn-success ${formData.pullRequestList.length > 0 ? 'hidden' : ''}`}
                                >Create Pull Request</button>
                            </div>
                            <div className="Pull-req-itms">
                                <ul className="list-group">
                                    {formData.pullRequestList.map((elelm, i) => {
                                        return (
                                            <li key={i} onClick={() => navigate_to_request_page(elelm)} className="list-group-item mt-3 d-flex justify-content-between align-items-center">
                                                Open Pull Request - {elelm.title} (#{elelm.number})
                                            </li>
                                        )
                                    })}
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div> */}

        </div>
    );
}
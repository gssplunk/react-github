module.exports = Object.freeze({
    file_name: 'Enter File name', // file name for configuration
    pull_req_title: 'New code has Updated',
    pull_req_body: 'Please pull need for update the current Changes.',
    pull_req_compare_branch: 'develop',
    pull_req_base_branch: 'master'
});
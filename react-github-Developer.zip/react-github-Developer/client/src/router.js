import React, { lazy, Suspense, useEffect } from 'react';
import { Route, withRouter, Switch, Redirect, BrowserRouter as Router } from 'react-router-dom';
import { connect } from 'react-redux';

import Components from './Container/Pages/Components';

const HomeContainer = lazy(() => {
    return import('./Container/Pages/Home');
})


const AppRoute = props => {
    useEffect(() => {
        console.log('props', props)
    }, []);

    let _routes = (
        <Router>
            <Components>
                <Switch>
                    <Route path="/" exact render={() => <HomeContainer Title={'React Github'} {...props} />} />
                </Switch>
            </Components>
        </Router>
    );

    return (
        <div><Suspense fallback={<Components><p>Loading</p></Components>}>{_routes}</Suspense></div>
    );
}



const mapStateToProps = (state) => ({
    testState: state.testReducer,
})

const mapDispatchToProps = {
    
}

const MainRoute = connect(mapStateToProps, mapDispatchToProps)(AppRoute);
export default withRouter(MainRoute);
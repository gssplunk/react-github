import React, { Component, Fragment } from 'react';
import { HomeComponent } from '../../Component/HomeComponent';
import { connect } from 'react-redux';
import {
    commit_code,
    get_all_pull_request,
    create_new_pull_request,
    get_existing_file,
    get_file_content
} from '../../Actions/Sevices';

import constants from '../../config';

class HomeContainer extends Component {
    constructor(props) {
        super(props);
        this.state = {
            content: '',
            file_name: constants.file_name, // file name configuration
            pull_req_title: constants.pull_req_title,
            pull_req_body: constants.pull_req_body,
            pull_req_compare_branch: constants.pull_req_compare_branch,
            pull_req_base_branch: constants.pull_req_base_branch,
            isLoader: false
        }
    }

    async componentDidMount() {
        this.enableLoader();
        await this.props.get_all_pull_request();
        await this.reload_file_data();
        setTimeout(() => {
            this.disableLoader();
        }, 1000);
    }

    reload_file_data = async () => {
        this.enableLoader();
        let file_response = await this.props.get_existing_file(this.state.file_name);
        if (file_response.success === 'true') {
            console.log("file_response::: ",file_response)
            // let file_content = await this.props.get_file_content(file_response.data.download_url);
            // console.log('file_response', file_content);
            // if (file_content.success === 'true') {
                this.setState({ content: file_response.data })
           // }
        }
        setTimeout(() => {
            this.disableLoader();
        }, 1000);
    }

    reload_PR_data = async () => {
        await this.props.get_all_pull_request();
    }

    enableLoader = () => {
        this.setState({ isLoader: true });
    }

    disableLoader = () => {
        this.setState({ isLoader: false });
    }

    code_commit = async (form) => {
        this.enableLoader();
        let code_commit_status = await this.props.commit_code({
            fileName: form.file_name,
            fileContent: form.editSection,
            commit_msg: form.commitMessage
        });

        console.log('code_commit_status', code_commit_status);
        await this.reload_file_data();
        if (code_commit_status && code_commit_status.success === 'true') {
            return true;
        } else return false;
    }

    new_pull_request = async () => {
        this.enableLoader();
        let response = await this.props.create_new_pull_request({
            pull_req_title: this.state.pull_req_title,
            pull_req_body: this.state.pull_req_body,
            pull_req_compare_branch: this.state.pull_req_compare_branch,
            pull_req_base_branch: this.state.pull_req_base_branch
        });

        await this.props.get_all_pull_request();
        this.disableLoader();
        return response;
    }

    render() {
        const { handleSubmit, submitting } = this.props;
        const { isLoader } = this.state;

        return (
            <Fragment>
                {
                    isLoader &&
                    <div id="preloader">
                        <div id="loader"></div>
                    </div>
                }
                <nav className="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
                    <div className="container">
                        <a className="navbar-brand">{this.props.Title}</a>
                    </div>
                </nav>
                <HomeComponent
                    {...this.props}
                    file_info={{ ...this.state }}
                    code_commit={this.code_commit}
                    new_pull_request={this.new_pull_request}
                    show={this.enableLoader}
                    reload_PR_data={this.reload_PR_data}
                    hide={this.disableLoader}
                />
            </Fragment>
        )
    }
}


const mapStateToProps = (state) => ({
    git: state.homeReducer,
})

const mapDispatchToProps = {
    commit_code,
    get_all_pull_request,
    create_new_pull_request,
    get_existing_file,
    get_file_content
}

export default connect(mapStateToProps, mapDispatchToProps)(HomeContainer)
import { GET_SUCCESS_PULL_REQUEST } from './Actions';
import axios from 'axios';

const BASE_URL = 'http://localhost:3002/api/';

export const get_all_pull_request = () => async (dispatch) => {
    try {
        const response = await axios.get(BASE_URL + 'git/getPullRequestList');
        if (response && response.hasOwnProperty('data') && response.data.hasOwnProperty('success')) {
            dispatch({ type: GET_SUCCESS_PULL_REQUEST, payload: response.data });
        } else {
            return response.data;
        }
    } catch (e) { }
};

export const commit_code = (param) => async (dispatch) => {
    try {
        const respose = await axios.post(BASE_URL + 'git/commitApi', param);
        if (respose && respose.hasOwnProperty('data') && respose.data.hasOwnProperty('success')) {
            return respose.data;
        } else {
            return respose.data;
        }
    } catch (e) { }
};

export const create_new_pull_request = (param) => async (dispatch) => {
    try {
        const respose = await axios.post(BASE_URL + 'git/createPullRequest', param);
        if (respose && respose.hasOwnProperty('data') && respose.data.hasOwnProperty('success')) {
            return respose.data;
        } else {
            return respose.data;
        }
    } catch (e) { }
};

export const get_existing_file = (file_name) => async (dispatch) => {
    try {
        const respose = await axios.get(BASE_URL + 'git/getSingleFileData/' + file_name);
        if (respose && respose.hasOwnProperty('data') && respose.data.hasOwnProperty('success')) {
            return respose.data;
        } else {
            return respose.data;
        }
    } catch (e) { }
};

export const get_file_content = (url) => async (dispatch) => {
    try {
        const respose = await axios.post(BASE_URL + 'git/getFileContent', { url });
        if (respose && respose.hasOwnProperty('data') && respose.data.hasOwnProperty('success')) {
            return respose.data;
        } else {
            return respose.data;
        }
    } catch (e) { }
};